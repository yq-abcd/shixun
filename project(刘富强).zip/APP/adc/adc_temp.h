#ifndef _adc_temp_H
#define _adc_temp_H

#include "sys.h"

void ADC_Temp_Init(void);
u16 Get_ADC_Temp_Value(u8 ch,u8 times);
int Get_Temperture(void);
int Get_Voltage(void);

#endif
