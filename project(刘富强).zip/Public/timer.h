#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"



void TIM1_CH1_CH4_PWM_Init(u16 arr,u16 pac);
void TIM3_CH1_PWM_Init(u16 arr,u16 psc);
void TIM4_Int_Init(u16 arr,u16 psc);


#endif
