//#include "esp8266.h"

////ATָ��
//u8 buff[64];


//const u8* wifiap_encryption="38813934028557141311";	//ԭ���Ʊ��
//const u8* wifiap_password="12345678"; 		//�������� 


////ATK-ESP8266���������,�����յ���Ӧ��
////str:�ڴ���Ӧ����
////����ֵ:0,û�еõ��ڴ���Ӧ����
////    ����,�ڴ�Ӧ������λ��(str��λ��)
//u8* atk_8266_check_cmd(u8 *str)
//{
//	
//	char *strx=0;
//	if(USART3_RX_STA&0X8000)		//���յ�һ��������
//	{ 
//		//printf("A");
//		USART3_RX_BUF[USART3_RX_STA&0X7FFF]=0;//���ӽ�����
//		strx=strstr((const char*)USART3_RX_BUF,(const char*)str);
//		//printf("%s\r\n",(u8*)strx);
//	} 
//	return (u8*)strx;
//}
////��ATK-ESP8266��������
////cmd:���͵������ַ���
////ack:�ڴ���Ӧ����,���Ϊ��,���ʾ����Ҫ�ȴ�Ӧ��
////waittime:�ȴ�ʱ��(��λ:10ms)printf("1");
////����ֵ:0,���ͳɹ�(�õ����ڴ���Ӧ����)
////       1,����ʧ��
//u8 atk_8266_send_cmd(u8 *cmd,u8 *ack,u16 waittime)
//{
//	u8 res=0; 
//	USART3_RX_STA=0;
//	//printf("1");
//	u3_printf("%s\r\n",cmd);	//��������
//	printf("%s\r\n",cmd);
//	//printf("2");
//	if(ack&&waittime)		//��Ҫ�ȴ�Ӧ��
//	{
//		//printf("3");
//		while(--waittime)	//�ȴ�����ʱ
//		{
//			delay_ms(10);
//			if(USART3_RX_STA&0X8000)//���յ��ڴ���Ӧ����
//			{
//				//printf("4");
//				if(atk_8266_check_cmd(ack))
//				{
//					//printf("5");
//					printf("ack:%s\r\n",(u8*)ack);
//					break;//�õ���Ч���� 
//				}
//					USART3_RX_STA=0;
//			} 
//		}
//		if(waittime==0)res=1; 
//	}
//	return res;
//} 


//void ESP8266_Upper_cloud(void)
//{
////	atk_8266_send_cmd("AT","OK",50);//AT
////	
////	atk_8266_send_cmd("AT+CWMODE=1","OK",50);//STAģʽ
////	
////	atk_8266_send_cmd("AT+RST","OK",50);//��λ
////	
////	while(atk_8266_send_cmd(("AT+CWJAP=\"%s\",\"%s\"","Mi10S","12345678"),"WIFI GOT IP",1000));//����·��������ȡIP

////	sprintf(buff,"AT+ATKCLDSTA=\"%s\",\"%s\"",wifiap_encryption,wifiap_password);//ԭ����
////	
////	while(atk_8266_send_cmd(buff,"CLOUD CONNECTED",1000));
//            atk_8266_send_cmd("AT","OK",50);//AT
//	
//            atk_8266_send_cmd("AT+CWMODE=1","OK",50);
//	
//            atk_8266_send_cmd("AT+RST","OK",50);
//	
//            sprintf((char*)buff,"AT+CWJAP=\"%s\",\"%s\",\"%s\"","liu","123456789");
//	
//            while(atk_8266_send_cmd(buff,"WIFI GOT IP",3000));
//	
//            //atk_8266_send_cmd("AT+CIPMUX=0","OK",20);
//            sprintf((char*)buff,"AT+ATKCLDSTA=\"%s\",\"%s\"","15655850922211952267","12345678");
//            while(atk_8266_send_cmd(buff,"CLOUD CONNECTED",1000));
//            //atk_8266_send_cmd("AT+CIPMODE=1","OK",200);
//            //atk_8266_send_cmd("AT+CIPSEND","OK",20);
//}
#include "esp8266.h"
#include "sys.h"
//#include "Serial.h"
#include "Delay.h"
//AT??
u8 buff[64];


const u8* wifiap_encryption="38813934028557141311";    //?????
const u8* wifiap_password="12345678";         //???? 


//ATK-ESP8266?????,????????
//str:???????
//???:0,???????????
//    ??,?????????(str???)
u8* atk_8266_check_cmd(u8 *str)
{
    
    char *strx=0;
    if(USART3_RX_STA&0X8000)        //????????
    { 
        //printf("A");
        USART3_RX_BUF[USART3_RX_STA&0X7FFF]=0;//?????
        strx=strstr((const char*)USART3_RX_BUF,(const char*)str);
        //printf("%s\r\n",(u8*)strx);
    } 
    return (u8*)strx;
}
//?ATK-ESP8266????
//cmd:????????
//ack:???????,????,??????????
//waittime:????(??:10ms)printf("1");
//???:0,????(??????????)
//       1,????
u8 atk_8266_send_cmd(u8 *cmd,u8 *ack,u16 waittime)
{
    u8 res=0; 
    USART3_RX_STA=0;
    //printf("1");
    u3_printf("%s\r\n",cmd);    //????
    printf("%s\r\n",cmd);
    //printf("2");
    if(ack&&waittime)        //??????
    {
        //printf("3");
        while(--waittime)    //?????
        {
           delay_ms(10);
            if(USART3_RX_STA&0X8000)//??????????
            {
                //printf("4");
                if(atk_8266_check_cmd(ack))
                {
                    //printf("5");
                    printf("ack:%s\r\n",(u8*)ack);
                    break;//?????? 
                }
                    USART3_RX_STA=0;
            } 
        }
        if(waittime==0)res=1; 
    }
    return res;
} 


void ESP8266_Upper_cloud(void)
{
//    atk_8266_send_cmd("AT","OK",50);//AT
//    
//    atk_8266_send_cmd("AT+CWMODE=1","OK",50);//STA??
//    
//    atk_8266_send_cmd("AT+RST","OK",50);//??

//    sprintf(buff,"AT+CWJAP=\"%s\",\"%s\"","liu","123456789");//wifi

//    atk_8266_send_cmd(buff,"WIFI GOT IP",1000);//?????,??IP

//    memset(buff, 0, sizeof(buff));
//    sprintf(buff,"AT+ATKCLDSTA=\"%s\",\"%s\"",wifiap_encryption,wifiap_password);//???
//    
//    atk_8266_send_cmd(buff,"CLOUD CONNECTED",1000);
}
