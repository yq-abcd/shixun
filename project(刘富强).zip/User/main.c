#include "system.h"
#include "delay.h"
#include "usart.h"
#include "usart3.h"
#include "adc_temp.h"
#include "tftlcd.h"
#include "AHT20-21_DEMO_V1_3.h"
#include "esp8266.h"
#include "lsens.h"

/*******************************************************************************
* �� �� ��         : main()
* ��������         : ������
* ��    ��         : ��
* ��    ��         : ��
*******************************************************************************/
int main()
{
    delay_init();
    USART1_Init(115200);
    usart3_init(115200);
    AHT20_Clock_Init();
		Lsens_Init();
	  TFTLCD_Init();
		FRONT_COLOR = BLACK;//���� 
    BACK_COLOR = WHITE; //���� 
    LCD_Clear(WHITE);//����  
		ADC_Temp_Init();
    delay_ms(1000);
  if((AHT20_Read_Status() & 0x18) != 0x18)
    {
        printf("AHT20��Ҫ��ʼ��...\r\n");
        AHT20_Start_Init();  
        Delay_1ms(75);
    } else 
    {
      printf("AHT20�Ѿ���\r\n");         
    }
    AHT20_Init();
    printf("AHT20��ʼ�����\r\n");  
  //  ESP8266_Upper_cloud();
  while(1)
    {
       uint32_t CT_data[2] = {0};  
       double humidity,temperature;
			 u16 light;
			 float vdda,internaltemp;
       humidity = 0;
       temperature = 0;
		   light=0;
			 vdda = 0;
			 internaltemp = 0;
			 light = Lsens_Get_Val();
			 vdda = Get_Voltage();
			 internaltemp = Get_Temperture();
       AHT20_Read_CTdata(CT_data);
       humidity = CT_data[0];
       humidity = CT_data[0] /1048576.0f * 100.0f;
       temperature = (CT_data[1] /1048576.0f)*200.0f-50.0f;
			 LCD_ShowString(10, 30, 200, 16, 16, "Humidity: ");
        LCD_ShowxNum(100, 30, (u32)(humidity), 4, 16, 0); // ʪ��
        LCD_ShowString(140, 30, 200, 16, 16, "%");

        LCD_ShowString(10, 50, 200, 16, 16, "Temperature: ");
        LCD_ShowxNum(120, 50, (u32)(temperature), 4, 16, 0); // �¶�
        LCD_ShowString(160, 50, 200, 16, 16, "C");

        LCD_ShowString(10, 70, 200, 16, 16, "Voltage: ");
        LCD_ShowxNum(90, 70, (u32)(vdda), 4, 16, 0); // ��ѹ
        LCD_ShowString(130, 70, 200, 16, 16, "V");

        LCD_ShowString(10, 90, 200, 16, 16, "Light: ");
        LCD_ShowxNum(70, 90, light, 3, 16, 0); // ���� 
        LCD_ShowString(100, 90, 200, 16, 16, "%");

        LCD_ShowString(10, 110, 200, 16, 16, "Chip Temp: ");
        LCD_ShowxNum(100, 110, (u32)(internaltemp), 4, 16, 0); // оƬ�¶�
        LCD_ShowString(140, 110, 200, 16, 16, "C");
       printf("ʪ��: %.1f%% RH\r\n", humidity );
       printf("�¶�: %.1f��C\r\n", temperature );	 
			 printf("ϵͳ��ѹ%.f\r\n",vdda);
			 printf("оƬ�¶�%.f\r\n",internaltemp);
       printf("����ǿ��%d\r\n",light);
       printf("-------------------\n");
       delay_ms(1000);
    }

}