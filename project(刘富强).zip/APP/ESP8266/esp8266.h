#ifndef _ESP8266_H_
#define _ESP8266_H_

#include "sys.h"
#include "usart.h"             //����
#include "delay.h"             //��ʱ
#include "usart3.h" 
#include "string.h" 


extern const u8* wifiap_encryption;	//WIFI AP �豸���
extern const u8* wifiap_password; 	//WIFI AP ����


u8 atk_8266_send_cmd(u8 *cmd,u8 *ack,u16 waittime);
void ESP8266_Upper_cloud(void);//����


#endif
